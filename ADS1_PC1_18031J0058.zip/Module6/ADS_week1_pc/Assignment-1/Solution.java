import java.util.Scanner;

class Node
{
	int data;
	Node Next;
	Node(int data)
	{
		this.data=data;
		this.Next=null;
	}
}
class Llist
{
	Node head;
	public void pushFront(int data)
	{
		Node n=new Node(data);
		
		n.Next=head;
		head=n;

		
	}
	
	public int popFront()
	{
		int a;
		if(head==null)
		{
			System.out.println("NO NODE");
			
		}
		if(head.Next==null)
		{   a=head.data;
			head=null;
			return a;
		}
		else
		{
			Node temp=head;
			a=head.data;
			head =head.Next;
			
			return a;
			}
		
		}

	public void disp() {
		Node tnode=head;
		while(tnode!=null)
		{
			System.out.print("Node :"+tnode.data);
			tnode=tnode.Next;
		}
		System.out.println("\n");
	}
	
	}
public class Solution {
public static void main(String args[])
{
	Llist list1 ;
	Llist list2;
	int y;
	Scanner scan=new Scanner(System.in);
	System.out.println("\n numberToDigits \n digitsToNumber \n addLargeNumber");
	Scanner sc = new Scanner(System.in);
	
	String x = sc.nextLine();
		switch(x)
		{
		case "numberToDigits":
			                    while(scan.hasNext())
								System.out.print(numberToDigits());
								break;
								
		case "digitsToNumber" :           
				                while(scan.hasNext())
			                    System.out.print(digitsToNumber(scan.nextLine()));
			                    break;
			
		case " addLargeNumbers":
			                    String p=scan.nextLine();
								String q=scan.nextLine();
								int a=Integer.parseInt(p);
								int b=Integer.parseInt(q);
								list1 =new Llist();
								list2=new Llist();
								Llist list3=new Llist();
								for(int i=0  ;i<p.length();i++)
								{
									int r=a%10;
									
									list1.pushFront(r);
									a=a/10;
								}
								for(int j=0;j<q.length();j++)
								{
									int r=b%10;
									list2.pushFront(r);
									b=b/10;
								}
								if(p.length()>q.length()) {
									int z=0,r=0;
								for(int k=0;k<p.length();k++)
								{
									int m=list1.popFront();
									int n=list2.popFront();
									z=m+n+r;
									if(z>9)
									{
										z=z%10;
										list3.pushFront(z);
									}
									r=z/10;
								}
								}
								break;
		
		}
	
	
	}


@SuppressWarnings("unused")
private static void addLargeNumbers() {
	// TODO Auto-generated method stub
	
	Llist list1 =p;
	Llist list2=q;
}


private static String digitsToNumber(String s) {
	// TODO Auto-generated method stub
	String string="sree";
	return string;
}

private static int numberToDigits() {
	// TODO Auto-generated method stub
	int z=Integer.parseInt(p);
	int x=z;
	Llist l1=new Llist();

	for(int i=0;i<p.length();i++)
	{
		
		int r=z%10;
		l1.pushFront(r);
		
		
		z=z/10;
	
	}
	l1.disp();
	return x;
	
}
}
